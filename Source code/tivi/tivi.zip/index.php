<?php 
	include ('./trangchu.php');
?>