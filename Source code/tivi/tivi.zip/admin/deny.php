<html>
<div style="text-align: center; font-size: 30;vertical-align: middle;">
<p>Bạn đã đăng nhập sai quá số lần cho phép, bạn bị khóa đăng nhập 30p.</p>
<p><a href="./../">Trở về trang chủ </a>
</div>
</html>