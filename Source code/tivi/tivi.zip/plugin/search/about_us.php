<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="sieunhan.css" media="all" />
<link rel="stylesheet" type="text/css" href="sieunhanmb.css" media="handheld" />
<title>AIW :: About Us</title>
</head>

<body>
	<div class="top" align="center">
    	<div class="banner">
        	 <div class="menu">
					<a href="index.php">Search</a>
					<a href="#">Advanced Search</a>
					<a href="#">Plugin</a>
					<a href="add_term.php">Add new term</a>
					<a href="about_us.php">About Us</a>
			  </div>
        </div>
    </div>
    <center>
        <div class="main">
        	
            <div class="content">
                <p>The are students of class 2C05, Faculty of Information, Hanoi University. Our project is <strong>Web Services Glossary</strong>, led by Msc. Nguyen Xuan Thang, the Advanced Internet and Web Service lecturer.</p>
                <p>There are 6 members in our group:
                <ul>
                	<li>Nguyen Thuy Dieu</li>
                	<li>Dinh Thi Duc</li>
                    <li>Le Thi Thanh Hoa</li>
                    <li>Nguyen Thi Thanh Thu</li>
                    <li>Luyen Thu Trang</li>
                    <li>Nguyen Thanh Van</li>
                </ul></p>
                <p><strong>Contact us:</strong> <a href="mailto:sieunhan2c@googlegroups.com">sieunhan2c@googlegroups.com</a></p>
                <center><img src="img/photo.gif" /></center>
            </div>
        </div>
    </center>
    <div class="bottom" align="center">
    	<div class="copyright">
        	© 2009 by <strong>sieunhan2c.com</strong><br />
            Advanced Internet and Web Services
        </div>
    </div>
</body>
</html>
