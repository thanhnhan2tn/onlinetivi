<?php

@mysql_connect('localhost','root','') or die ("Could not connect to the server");

@mysql_select_db('search') or die("Could not connect to the DB");


?>