<?php
	$hostname = 'localhost';
	$dbName	=	'nhapmon_tivi';
	$dbUser = 'nhapmon_tivi';
	$dbPass = 'nhapmon%^&';
	$mainurl = '/tivi/';
	$mainfile = 'trangchu.php';
	$sitename= 'Truyền Hình Trực Tuyến';
	$tentrang = 'Website Truyền Hình Trực Tuyến';
	$copyright = "© Nhóm nhập môn CNPM";
?>