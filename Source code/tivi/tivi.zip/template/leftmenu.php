<div id="menu_cat" class="menu" >
	  <div class="navbar navbar-static-top navbar-inverse" style="color: #fff; padding: 0; margin: 0;">
	  <h3><span class="glyphicon glyphicon-list-alt" style="padding-right:10px;" ></span>Danh mục</h3>
	  </div>
		<?php
			show_cat(); //Hien thi danh sach Category
		?>
</div>