
<div class="footer">
		
		<ul class="container foot_menu">
			<li class="glyphicon glyphicon-home"><a href="./">Trang chủ</a></li>
			<!-- li class="glyphicon glyphicon-envelope"><a href="./?gopy">Liên hệ, góp ý</a></li -->
			<li class="glyphicon glyphicon-envelope"><a href="./gopy.html">Liên hệ, góp ý</a></li> 
			<!-- <li class="glyphicon glyphicon-envelope"><a href="./huongdan.html">Hướng dẫn</a></li> 
			 -->
		</ul>
    		<p><a class="rol_top" href="#top"><span class="glyphicon glyphicon-arrow-up"></span>Top</a>
    </div>
<?php // footer
	//include_once './plugin/thongke.php';
?>
<script type="text/javascript">
	$("#mobile").click(function() {
  		(jQuery)("#mobile").html("Chú ý:<br /><li>Hỗ trợ chạy trực tiếp trên Android có Cài đặt <a href=\"./file/Firefox_28.0.1.apk\">Firefox For Android</a> *(<a href=\"https://play.google.com/store/apps/details?id=org.mozilla.firefox\">Link CH Play</a>) và Adobe Flash Player (<a href=\"./file/AdobeFlashPlayer11.1_2.x.apk\">Android 2.x, 3.x</a> - <a href=\"./file/AdobeFlashPlayer11.1_11.1.115.81.apk\">Android 4.X trở lên</a>)</li><li>Chưa hỗ trợ xem trực tiếp cho iOS và Windows Phone</li></div>");
  	
	});
	$("#mobile").click(function() {
		(jQuery)("#mobile2").attr('class', 'showmobile');
  	
	});
</script>
</body>
</html>